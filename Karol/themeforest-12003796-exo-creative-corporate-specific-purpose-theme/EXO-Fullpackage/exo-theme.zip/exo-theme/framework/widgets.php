<?php
get_template_part('framework/widgets/tweets');
get_template_part('framework/widgets/news_tabs');
get_template_part('framework/widgets/recent_post_v1');
get_template_part('framework/widgets/recent_post_v2');
get_template_part('framework/widgets/social');
get_template_part('framework/widgets/newsletter');
get_template_part('framework/widgets/facebook');
get_template_part('framework/widgets/instagram');
get_template_part('framework/widgets/woo_search');
get_template_part('framework/widgets/widget-flickrphotos');
require ('widgets/cart_search.php');